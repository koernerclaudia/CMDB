# CMDB
This will be a movie database with an API built from scratch. (CMDB = Claudia's Movie Database)
